﻿/*
 파일을 드래그 해 폼에 놓으면 해당 파일의 이름을 리스트박스에
 출력하는 파일입니다.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; //Path클래스를 사용하기 위해 필요합니다.

/*
 * 폼의 '속성'에서 AllowDrop을 True로 바꿉니다.
 * 그리고 폼의 '이벤트'에서 각각 DragDrop과 DragEnter 이벤트에 대한 
 * 처리코드를 작성합니다.
 */

namespace Drag
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //끌어서 놓기 작업이 완료될 때 발생
        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            foreach(var file in files)
            {
                string str = Path.GetFileNameWithoutExtension(file); // 파일명만 추출
                listBox1.Items.Add(str);
            }
        }

        //파일을 컨트롤의 범위 안으로(여기서는 폼) 끌 때 발생
        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
            //끌어서 가져온 파일의 정보를 가져오기
        }
    }
}
